/**
 * midi-range-fix | range-fix.js
 * v1.0.2
 *
 * Corrige le calcul de portée midi-qol pour les tokens Large/Huge/Gargantuan.
 *
 * Règle : chaque token a un rayon naturel (2.5ft par case au-delà de Medium).
 * La portée effective d'une attaque est mesurée du CENTRE de l'attaquant
 * jusqu'au BORD de la cible (centre → bord).
 *
 * Portée effective = portée_arme + (taille_attaquant - 1) × 2.5ft
 *   - Attaquant Medium (1 case) : 5ft → 5ft
 *   - Attaquant Large  (2 cases) : 5ft → 7.5ft
 *   - Attaquant Huge   (3 cases) : 5ft → 10ft
 *
 * Implémentation :
 *   1. On remplace le point cible par le bord le plus proche du token cible.
 *   2. On soustrait du résultat le bonus de taille de l'attaquant.
 *   3. midi-qol compare au weapon_range habituel → résultat correct.
 *
 * Forme du bord cible :
 *   - Token carré (width = height) → cercle inscrit (évite biais diagonal).
 *   - Token non-carré (width ≠ height) → bounding box rectangulaire.
 */

export function RangeFixHooks() {
    Hooks.once("ready", () => {
        if (!game.modules.get("midi-qol")?.active) {
            console.log("[midi-range-fix] midi-qol non actif — module désactivé.");
            return;
        }

        _patchMeasurePath();
        console.log("[midi-range-fix] Patch centre→bord actif.");
    });
}

function _patchMeasurePath() {
    const original = canvas.grid.measurePath.bind(canvas.grid);

    canvas.grid.measurePath = function(waypoints, options) {
        if (!waypoints || waypoints.length !== 2) {
            return original(waypoints, options);
        }

        const [src, tgt] = waypoints;

        // Identifier l'attaquant (centre ≈ src, tolérance 2px)
        const attacker = canvas.tokens.placeables.find(t => {
            if (!t.actor) return false;
            const c = t.center;
            return Math.abs(c.x - src.x) < 2 && Math.abs(c.y - src.y) < 2;
        });
        if (!attacker) return original(waypoints, options);

        // Identifier la cible (tgt est dans ses bounds)
        const target = canvas.tokens.placeables.find(t => {
            if (!t.actor || t === attacker) return false;
            const b = t.bounds;
            return tgt.x >= b.x && tgt.x <= b.x + b.width
                && tgt.y >= b.y && tgt.y <= b.y + b.height;
        });
        if (!target) return original(waypoints, options);

        // Aucune correction nécessaire si les deux tokens sont Medium
        const attackerWidth = attacker.document.width;
        const targetWidth   = target.document.width;
        if (attackerWidth <= 1 && targetWidth <= 1) return original(waypoints, options);

        // 1. Point le plus proche sur la bordure réelle de la cible
        cons