(() => {
})();

import { ChatHooks } from './modules/chat.js';
import { ImageHooks } from './modules/image.js';
import { PlayerHooks } from './modules/player.js';
import { ScenesHooks } from './modules/scenes.js';
import { Relationship } from './modules/relations/relationship.js';
import { RelationModel } from './modules/relations/relation-model.js';
import { ActorSheetWithRelations } from "./modules/relations/actor-sheet-with-relations.js";
import { RelationItemSheet } from "./modules/relations/relation-item.js";

Hooks.on("init", async () => {
    const partials = [
        "modules/westmarch/templates/actors/tabs/character-relations.hbs"
      ];
    const paths = {};
    for ( const path of partials ) {
        paths[path.replace(".hbs", ".html")] = path;
        paths[`dnd5e.${path.split("/").pop().replace(".hbs", "")}`] = path;
      };
    await loadTemplates(paths);

    Object.assign(CONFIG.Item.dataModels, {
      "westmarch.relation": RelationModel
    });

    Actors.registerSheet("dnd5e", ActorSheetWithRelations, { types: ["character"], makeDefault: true, label: "Actor Sheet with Relations" });
    Items.registerSheet("dnd5e", RelationItemSheet, { types: ["westmarch.relation"], makeDefault: true });

    Handlebars.registerHelper('for', function(from, to, incr, block) {
        var accum = '';
        for(var i = from; i < to; i += incr)
            accum += block.fn(i);
        return accum;
    });

    Handlebars.registerHelper("lte", function(a, b) {
        return a <= b;
      });

    ChatHooks();
    ImageHooks();
    PlayerHooks();
    ScenesHooks();
    Relationship();
});

//----------------------------------------------
