export class ActorSheetWithRelations extends dnd5e.applications.actor.CharacterActorSheet {

  _filters = {
    inventory: { name: "", properties: new Set() },
    spellbook: { name: "", properties: new Set() },
    features: { name: "", properties: new Set() },
    effects: { name: "", properties: new Set() },
    relations: { name: "", properties: new Set() }
  }

  static PARTS = {
    ...super.PARTS,

    relations: {
      container: { classes: ["tab-body"], id: "tabs" },
      template: "modules/westmarch/templates/actors/tabs/character-relations.hbs",
      scrollable: [""]
    }
  };


  static TABS = [
    ...super.TABS,
    { tab: "relations", label: "Relations", icon: "fas fa-users" }
  ];

  static get name() {
    return "CharacterActorSheet";
  }

  async _prepareContext(options = {}) {
    const data = await super._prepareContext(options);
    console.error(data);
    await this.prepareRelationsCleanup();
    // On filtre les "relations" parmi les feats
    data.relations = this.actor.items.filter(item => item.type === "westmarch.relation");
  
    return data;
  }

  async prepareRelationsCleanup() {
    const relations = this.actor.items.filter(item => item.type === "westmarch.relation");
    const toDelete = [];
  
    for (const relation of relations) {
      const targetId = relation.system.targetId; // Adapté à comment tu stockes ça
      if (targetId && !game.actors.get(targetId)) {
        toDelete.push(relation.id);
      }
    }
  
    if (toDelete.length > 0) {
      await this.actor.deleteEmbeddedDocuments("Item", toDelete);
    }
  }
}