const { SchemaField: SchemaField$z, HTMLField: HTMLField$8 } = foundry.data.fields;

export class RelationModel extends foundry.abstract.TypeDataModel {
    static defineSchema() {
        const fields = foundry.data.fields;
        return {
          targetId: new fields.DocumentIdField({required: true}),
          value: new fields.NumberField(),
          description: new SchemaField$z({
            value: new HTMLField$8({required: true, nullable: true, label: "DND5E.Description"}),
            chat: new HTMLField$8({required: true, nullable: true, label: "DND5E.DescriptionChat"})
          }),
        };
      }
    
      prepareDerivedData() {
      }

   /**
   * Render a rich tooltip for this item.
   * @param {EnrichmentOptions} [enrichmentOptions={}]  Options for text enrichment.
   * @returns {{content: string, classes: string[]}}
   */
  async richTooltip(enrichmentOptions={}) {
    return {
      content: await renderTemplate(
        "modules/westmarch/templates/actors/tabs/character-relation-tooltip.hbs", this.parent
      ),
      classes: ["dnd5e2", "dnd5e-tooltip", "item-tooltip"]
    };
  }

  /**
   * Prepare item card template data.
   * @param {EnrichmentOptions} [enrichmentOptions={}]  Options for text enrichment.
   * @param {Activity} [enrichmentOptions.activity]     Specific activity on item to use for customizing the data.
   * @returns {Promise<object>}
   */
  async getCardData({ activity, ...enrichmentOptions }={}) {
    const { name, type, img } = this.parent;
    let {
      price, weight, uses, identified, unidentified, description, school, materials
    } = this;


    const chat = description.chat || description.value;
    description = description.value;
    uses = this.hasLimitedUses && (game.user.isGM || identified) ? uses : null;
    price = game.user.isGM || identified ? price : null;

    let subtitle = '';
    for (let i = 1; i < 6; i++) {
      if (i <= this.value)
        subtitle += '<span class="fa-solid fa-heart checked"></span>';
      else 
        subtitle += '<span class="fa-solid fa-heart"></span>';
    }
    const context = {
      name, type, img, price, weight, uses, school, materials,
      config: CONFIG.DND5E,
      controlHints: game.settings.get("dnd5e", "controlHints"),
      labels: foundry.utils.deepClone((activity ?? this.parent).labels),
      tags: this.parent.labels?.components?.tags,
      subtitle: subtitle,
      description: {
        value: chat ?? description,
        chat: chat,
        concealed: false
      }
    };

    context.properties = [];

    if ( game.user.isGM || isIdentified ) {
      context.properties.push(
        ...this.cardProperties ?? [],
        ...Object.values((activity ? activity?.activationLabels : this.parent.labels.activations?.[0]) ?? {}),
        ...this.equippableItemCardProperties ?? []
      );
    }

    context.properties = context.properties.filter(_ => _);
    context.hasProperties = context.tags?.length || context.properties.length;
    return context;
  }
}