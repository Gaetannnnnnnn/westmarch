export class RelationItemSheet extends dnd5e.applications.item.ItemSheet5e2 {
    /** @inheritdoc */
    get template() {
      return `modules/westmarch/templates/items/relation.hbs`
    }
  }