export function Relationship() {
  Hooks.once("ready", () => {
    game.westmarch = game.westmarch || {};
  });

    // Ajouter un hook pour obtenir les options du menu contextuel pour chaque item
    Hooks.on("dnd5e.getItemContextOptions", (item, menuItems) => {
      console.log("Item context options:", item, menuItems);
      if(item.type === 'westmarch.relation') menuItems.splice(5, 3);
    });

  Hooks.on("createToken", async (tokenDoc) => {
    const newActor = tokenDoc.actor;
    if (!newActor) return;

    for (const otherToken of canvas.tokens.placeables) {
      if (newActor.type === "npc") continue;
      if (otherToken.actor.id === tokenDoc.actor.id) continue;
      const otherActor = otherToken.actor;
      if (!otherActor) continue;
  
      // Vérifie si déjà une relation existe
      const alreadyExists = newActor.items.find(i => i.type === "westmarch.relation" && i.system.targetId === otherActor.id);
      if (!alreadyExists) {
        await newActor.createEmbeddedDocuments("Item", [{
          name: otherActor.name,
          type: "westmarch.relation",
          img: otherActor.img,
          system: {
            targetId: otherActor.id,
            value: 3,
            description: {
              value: '',
              chat: ''
            }
          }
        }]);
      }

      const reverseExists = otherActor.items.find(i => i.type === "westmarch.relation" && i.system.targetId === newActor.id);
      if (!reverseExists) {
        await otherActor.createEmbeddedDocuments("Item", [{
          name: newActor.name,
          type: "westmarch.relation",
          img: newActor.img,
          system: {
            targetId: newActor.id,
            value: 3,
            description: {
              value: '',
              chat: ''
            }
          }
        }]);
      }
    }
  });
}
