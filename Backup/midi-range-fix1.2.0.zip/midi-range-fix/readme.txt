================================================================================
                 SORUTA — MIDI RANGE FIX (ELLIPSES)
                      Module Foundry VTT — Privé
================================================================================

Version : 1.2.0
Auteur  : Soruta (Discord : s0ruta)
Système : dnd5e sur Foundry VTT v13+
Accès   : © 2026 Soruta — Tous droits réservés. Usage personnel autorisé.
          Toute redistribution, modification ou usage commercial est
          strictement interdit sans autorisation écrite.

--------------------------------------------------------------------------------
DESCRIPTION
--------------------------------------------------------------------------------

Corrige le calcul de portée de midi-qol pour les tokens Large, Huge et
Gargantuan. Sans ce fix, midi-qol mesure du centre de l'attaquant vers
plusieurs coins du token cible, ce qui donne ~5.82ft au lieu de 5ft pour des
tokens adjacents — bloquant des attaques de mêlée à 5ft légitimes.

Le fix intercepte canvas.grid.measurePath et remplace le point cible par le
point le plus proche sur la bordure du token (mesure centre → bord).

Exemple :
  - vs Large  (2 cases) : ~2.5ft centre→bord → autorisé ✓  [corrigé]
  - vs Huge   (3 cases) : ~2.5ft centre→bord → autorisé ✓  [corrigé]
  - 1 case de gap       : ~7.5ft centre→bord → bloqué   ✓

--------------------------------------------------------------------------------
FICHIERS
--------------------------------------------------------------------------------

index.js
   Point d'entrée du module. Initialise RangeFixHooks au hook "init".

modules/range-fix.js
   Patch de canvas.grid.measurePath : remplace le point cible par le bord le
   plus proche du token pour les tokens Large+. Les tokens Medium sont
   inchangés. Se désactive silencieusement si midi-qol n'est pas actif.

--------------------------------------------------------------------------------
PARAMÈTRES CONFIGURABLES
--------------------------------------------------------------------------------

Accessibles via : Paramètres du jeu → Configuration des modules → Soruta — Midi Range Fix

  Activer le fix de portée (rechargement requis)

La page de paramètres affiche également un tableau explicatif du calcul.

Dépendance : midi-qol doit être actif. Sans lui, le module ne fait rien.

--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

1. Dans Foundry : Setup → Add-on Modules → Install Module
2. Coller l'URL du manifest dans le champ "Manifest URL" :
   https://raw.githubusercontent.com/Gaetannnnnnnn/westmarch/main/midi-range-fix/module.json
3. Cliquer "Install"
4. Activer le module dans le monde : Setup → Gérer les modules

================================================================================
                    MIDI-RANGE-FIX — MISES À JOUR
================================================================================

v1.2.0 | 2026-07-24
   range-fix.js — Fix patch perdu après la première attaque. Cause racine :
   midi-qol ou libWrapper appelle Object.defineProperty(canvas.grid,
   'measurePath', { value: fn }) pendant le workflow d'attaque, remplaçant
   notre getter/setter (configurable: true) par un value descriptor sans
   déclencher notre setter. Résultat : dès l'attaque 1, notre getter est
   détruit ; l'attaque 2 utilise la version midi-qol sans correction bord→bord.
   Nouvelle architecture triple couche :
     1. _ourPatch déplacé en portée MODULE (référence stable, marquée par un
        Symbol _PATCH_MARK) — comparaisons === fiables inter-appels.
     2. Object.defineProperty getter/setter conservé (résiste aux assignments).
     3. Hook dnd5e.preUseItem : réinstalle le getter/setter avant chaque item
        use, avant que midi-qol ne démarre son workflow.
     4. Polling setInterval 250ms : détecte si le descripteur est redevenu un
        value descriptor (remplacement tiers via Object.defineProperty) et
        réinstalle immédiatement.
   _readCurrentFn() lit le descripteur brut (sans passer par notre getter) pour
   capturer un _trueOriginal non circulaire. canvasInit arrête le polling proprement.

v1.1.3 | 2026-07-23
   range-fix.js — Patch rendu permanent via Object.defineProperty : au lieu de
   remplacer canvas.grid.measurePath directement (ce que midi-qol écrasait à
   chaque workflow d'attaque), on pose un getter/setter sur la propriété.
   Le getter renvoie toujours notre fonction bord→bord, quelle que soit la scène.
   Le setter intercepte les réécritures de midi-qol, met à jour le fallback
   interne (_trueOriginal) pour qu'on appelle toujours la bonne version de
   midi-qol en dernier recours, mais ne laisse jamais sa version exposée.
   Résultat : le fix survit à tous les lancers sans re-ciblage requis.
   Try-catch conservé pour sécurité. Hook targetToken retiré (inutile).

v1.1.2 | 2026-07-23
   range-fix.js — (intermédiaire, remplacé par 1.1.3) Guard ._mrf + hook
   targetToken + try-catch. Le targetToken ne fonctionnait pas quand la cible
   restait la même entre deux attaques.

v1.1.1 | 2026-07-23
   index.js — RangeFixHooks() déplacé de "init" vers "ready". Le listener
   canvasReady était enregistré trop tôt (init) : midi-qol enregistre le sien
   dans "ready", donc son handler s'exécutait après le nôtre et écrasait le patch.
   En déplaçant dans "ready" et en profitant de l'ordre alphabétique (midi-qol <
   midi-range-fix), notre canvasReady est enregistré en dernier et s'exécute après
   celui de midi-qol.
   range-fix.js — Ajout d'un setTimeout(0) dans le handler canvasReady pour
   repousser l'application du patch après tous les handlers synchrones, garantissant
   que notre version est bien la dernière active quelle que soit la version de
   midi-qol.

v1.1.0 | 2026-07-23
   range-fix.js — Refonte complète de la mesure de portée.
   Ancienne approche : centre attaquant → bord cible − bonus taille. Incorrecte
   pour Medium attaquant vs Large cible (le demi-espace du PJ n'était pas
   soustrait → 6.9ft au lieu de 1.6ft pour un PJ adjacent à un Brown Bear).
   Nouvelle approche : bord→bord. On calcule le point le plus proche sur la
   bounding box de l'attaquant depuis le centre de la cible, et vice-versa ;
   la distance entre ces deux points est la portée D&D 5e exacte.
   Hook "ready" → "canvasReady" : canvas.grid est recréé à chaque chargement
   de scène, le patch ne survivait pas. canvasReady re-patche à chaque scène.
   Ajout de la vérification du setting "enabled" dans le hook canvasReady.

v1.0.9 | 2026-07-23
   settings.js — Fix hook renderSettingsConfig pour Foundry v13 : html passé en
   HTMLElement natif (pas jQuery). Ajout de $(html) pour normaliser. Sélecteur
   remplacé par [data-setting-id^="midi-range-fix."] (robuste v12/v13, sans
   dépendance sur .tab[data-tab="system"] qui n'existe plus en v13). Description
   du tableau mise à jour (bounding box, plus cercle inscrit).

v1.0.8 | 2026-07-23
   Synchronisation module.json / readme.txt sur la même version.

v1.0.7 | 2026-07-23
   range-fix.js — Remplacement du cercle inscrit par la bounding box rectangulaire
   dans _nearestBorderPoint. Le cercle sur-estimait la distance en approche diagonale
   d'un coin de token Large : ex. Brown Bear diagonalement adjacent = 5.6ft au lieu
   de 3.5ft → Foundry arrondissait à 6ft et bloquait l'attaque à tort. La bounding
   box (point le plus proche sur le rectangle) correspond exactement au "nearest cell
   edge" de D&D 5e sur grille carrée, sans biais diagonal.

v1.0.6 | 2026-07-22
   range-fix.js — Fix centres de cases (Foundry v13) :
   - token.center renvoie le centre de la 1ère case, pas le centre géométrique
     du token. Remplacement par _boundsCenter() basé sur token.bounds, partout
     (attaquant + calcul du cercle inscrit dans _nearestBorderPoint).
   - Identification de l'attaquant maintenant uniquement par bounds (plus
     robuste que la recherche par centre).

v1.0.5 | 2026-07-22
   range-fix.js — Fix asymétrie PJ / mob :
   - Identification de l'attaquant en double passe : centre d'abord (tolérance
     5px), puis fallback bounds si src = bord (cas Large mob avec midi-qol).
   - Mesure toujours depuis attacker.center (pas src) → comportement identique
     PJ et mob, plus de biais centre→bord vs bord→centre.

v1.0.4 | 2026-07-22
   settings.js — Toggle d'activation + bloc explicatif injecté dans la page
   de config (formule + tableau des cas d'usage).
   styles/midi-range-fix.css — Styles du bloc explicatif.

v1.0.3 | 2026-07-22
   range-fix.js — Copyright ajouté. Titre mis à jour : Soruta — Midi Range Fix.
   Installation readme mise à jour (manifest URL GitHub).
