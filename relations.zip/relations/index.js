import { registerSettings }  from './modules/settings.js';
import { RelationsHooks }    from './modules/relations.js';
import { AshCharacterSheet } from './modules/character-sheet.js';

Hooks.on("init", () => {
    // Déclare ce module pour le nettoyage lors de l'export "fiche originale"
    CONFIG.asharaSheetsModules ??= [];
    CONFIG.asharaSheetsModules.push("relations");

    registerSettings();
    RelationsHooks();

    // Remplace la fiche personnage dnd5e par défaut
    Actors.registerSheet("dnd5e", AshCharacterSheet, {
        types:       ["character"],
        makeDefault: true,
        label:       "Soruta — Fiche personnage"
    });

    // Expose la classe pour les modules dépendants (ex: ashara-bestiary)
    CONFIG.asharaSheets ??= {};
    CONFIG.asharaSheets.relations = AshCharacterSheet;
});
